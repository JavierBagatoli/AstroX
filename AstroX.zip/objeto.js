const objeto = [{
    nombre : "Javier",
    edad : 22,
    puesto : "ingeniero",
    entorno : [
        "https://calendar.google.com/calendar/u/0/r",
        "http://localhost:8080/api/v1/Empleados",
        "https://www.youtube.com/watch?v=xOinGb2MZSk&t=24137s"
    ],
    tareas : [
        "Caminar", "Probar cohetes", "Verificar combustible", "Trazar orbita"
    ],
    tareasConcluidas : [
        "Respirar"
    ]

},{
    nombre : "Paki",
    edad : 21,
    puesto : "Asistente",
    entorno : [
        "https://www.google.com"
    ],
    tareas : [
        "Caminar", "Limpieza", "Revision de calculos"
    ],
    tareasConcluidas : [
        "Correr"
    ]

},]
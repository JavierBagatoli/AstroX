class Pagina{
    constructor(nav, cuerpo, persona){
        this.nav = nav;
        this.persona = perosna;
        this.cuerpo = cuerpo;
    }

}